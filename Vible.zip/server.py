import os
import sys
import subprocess

# Set UTF-8 encoding for system standard I/O
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# --- Auto-install required third-party packages on fresh PCs / laptops ---
REQUIRED_PACKAGES = [
    ("fastapi", "fastapi>=0.100.0"),
    ("uvicorn", "uvicorn[standard]>=0.23.0"),
    ("aiofiles", "aiofiles>=23.0.0"),
    ("PIL", "pillow>=10.0.0"),
    ("mutagen", "mutagen>=1.47.0"),
    ("chardet", "chardet>=5.0.0"),
    ("cv2", "opencv-python-headless>=4.8.0"),
    ("multipart", "python-multipart>=0.0.6")
]

missing_packages = []
for mod_name, pkg_spec in REQUIRED_PACKAGES:
    try:
        __import__(mod_name)
    except ImportError:
        missing_packages.append(pkg_spec)

if missing_packages:
    print("=" * 64)
    print("  [VibeVault] 필수 라이브러리를 자동으로 설치합니다...")
    print(f"  설치 목록: {', '.join(missing_packages)}")
    print("  (최초 1회만 자동 실행되며 약 30초~1분 정도 소요됩니다)")
    print("=" * 64)
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing_packages])
        print("=" * 64)
        print("  [VibeVault] 모든 필수 패키지 설치 완료! 서버를 시작합니다.")
        print("=" * 64)
    except Exception as err:
        print(f"  [오류] 패키지 자동 설치 실패: {err}")
        print("  인터넷 연결을 확인하시거나 'pip install -r requirements.txt'를 수동 실행해주세요.")
        input("  계속하려면 엔터 키를 누르세요...")
        sys.exit(1)

import io
import time
import json
import mimetypes
import zipfile
import hashlib
import re
import socket
import shutil
from pathlib import Path
from typing import Optional, List, Dict, Any

SERVER_START_TIME = time.time()

from fastapi import FastAPI, Request, Query, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import aiofiles
import cv2
import PIL.Image
import PIL.ImageOps
import mutagen
import chardet
import html
import urllib.parse

# Allow large image files without DecompressionBomb error
PIL.Image.MAX_IMAGE_PIXELS = None

# Base Paths
WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(WORKSPACE_DIR, ".."))

DATA_DIR = os.path.join(WORKSPACE_DIR, "data")
CACHE_DIR = os.path.join(WORKSPACE_DIR, ".cache", "thumbnails")
COVERS_DIR = os.path.join(WORKSPACE_DIR, ".cache", "covers")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(COVERS_DIR, exist_ok=True)

CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
LIBRARIES_FILE = os.path.join(DATA_DIR, "libraries.json")
COVERS_FILE = os.path.join(DATA_DIR, "covers.json")

def find_media_root_candidates() -> List[str]:
    """Finds possible external hard drive media directories on Windows."""
    candidates = []
    if sys.platform == "win32":
        import string
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if os.path.exists(drive):
                target = os.path.join(drive, "대기방")
                if os.path.exists(target) and os.path.isdir(target):
                    candidates.append(target)
                elif letter not in ["C"]:
                    candidates.append(drive)
    return candidates

def load_config() -> Dict[str, Any]:
    default_config = {
        "media_root": ""
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                default_config.update(cfg)
        except Exception:
            pass
    return default_config

def save_config(cfg: Dict[str, Any]):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

def resolve_initial_media_root() -> str:
    # 1. Explicitly configured path in config.json
    cfg = load_config()
    cfg_root = cfg.get("media_root", "").strip()
    if cfg_root and os.path.exists(cfg_root) and os.path.isdir(cfg_root):
        return os.path.abspath(cfg_root)

    # 2. Environment variable
    env_root = os.environ.get("VIBEVAULT_MEDIA_ROOT", "").strip()
    if env_root and os.path.exists(env_root) and os.path.isdir(env_root):
        return os.path.abspath(env_root)

    # 3. Parent directory of workspace (where 바이브코딩 folder is placed)
    if os.path.exists(PARENT_DIR) and os.path.isdir(PARENT_DIR):
        return PARENT_DIR

    # 4. Auto-detect external drive with '대기방'
    candidates = find_media_root_candidates()
    if candidates:
        return candidates[0]

    return PARENT_DIR

MEDIA_ROOT = resolve_initial_media_root()

# Initialize persistent files if not present
if not os.path.exists(LIBRARIES_FILE):
    with open(LIBRARIES_FILE, "w", encoding="utf-8") as f:
        json.dump([
            {
                "id": "lib_asmr",
                "title": "🎧 ASMR 음성 & 음악 컬렉션",
                "desc": "외장하드의 고음질 사운드 및 음성 드라마 가상 보관함",
                "coverUrl": "",
                "folders": [
                    {"path": "asmr", "name": "asmr", "added_at": "2026-09-15T12:00:00"}
                ]
            }
        ], f, ensure_ascii=False, indent=2)

if not os.path.exists(COVERS_FILE):
    with open(COVERS_FILE, "w", encoding="utf-8") as f:
        json.dump({}, f, ensure_ascii=False, indent=2)

app = FastAPI(title="VibeVault Local Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------- Helper Functions -----------------

FAVICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <defs>
    <linearGradient id="vvGrad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#be123c"/>
      <stop offset="50%" stop-color="#f43f5e"/>
      <stop offset="100%" stop-color="#4f46e5"/>
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#f43f5e" flood-opacity="0.4"/>
    </filter>
  </defs>
  <!-- Rounded Base Card -->
  <rect x="2" y="2" width="60" height="60" rx="14" fill="url(#vvGrad)" filter="url(#glow)"/>
  <rect x="2.5" y="2.5" width="59" height="59" rx="13.5" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>
  
  <!-- Server Rack Icon (Lucide-inspired) -->
  <rect x="15" y="14" width="34" height="14" rx="3" fill="none" stroke="#ffffff" stroke-width="2.6" stroke-linejoin="round"/>
  <line x1="20" y1="21" x2="21" y2="21" stroke="#ffffff" stroke-width="2.6" stroke-linecap="round"/>
  <line x1="27" y1="21" x2="28" y2="21" stroke="#ffffff" stroke-width="2.6" stroke-linecap="round"/>

  <rect x="15" y="32" width="34" height="14" rx="3" fill="none" stroke="#ffffff" stroke-width="2.6" stroke-linejoin="round"/>
  <line x1="20" y1="39" x2="21" y2="39" stroke="#ffffff" stroke-width="2.6" stroke-linecap="round"/>
  <line x1="27" y1="39" x2="28" y2="39" stroke="#ffffff" stroke-width="2.6" stroke-linecap="round"/>

  <!-- 24H Live Online Indicator (Green Pulse Dot) -->
  <circle cx="48" cy="16" r="4.5" fill="#10b981"/>
  <circle cx="48" cy="16" r="6.5" fill="none" stroke="#10b981" stroke-width="1.2" opacity="0.6"/>
</svg>"""

def is_tailscale_ip(ip: str) -> bool:
    """Checks if an IP address belongs to Tailscale CGNAT range (100.64.0.0/10)."""
    try:
        parts = [int(p) for p in ip.split(".")]
        return len(parts) == 4 and parts[0] == 100 and (64 <= parts[1] <= 127)
    except Exception:
        return False

def get_lan_ips() -> List[str]:
    """Returns local LAN & Tailscale IP addresses for mobile & cross-device access."""
    ips = []
    try:
        hostname = socket.gethostname()
        for ip in socket.gethostbyname_ex(hostname)[2]:
            if not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    if not ips:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ips.append(s.getsockname()[0])
            s.close()
        except Exception:
            pass
    # Priority: 1) Tailscale (100.x.y.z) for direct mobile/remote, 2) 192.168.x.x, 3) 10.x.x.x / 172.x.x.x, 4) others
    def ip_priority(ip_str):
        if is_tailscale_ip(ip_str):
            return 0
        elif ip_str.startswith("192.168."):
            return 1
        elif ip_str.startswith("10.") or ip_str.startswith("172."):
            return 2
        return 3
    ips = list(dict.fromkeys(ips))
    ips.sort(key=ip_priority)
    return ips

def format_uptime(seconds: float) -> str:
    secs = int(seconds)
    days = secs // 86400
    hours = (secs % 86400) // 3600
    minutes = (secs % 3600) // 60
    if days > 0:
        return f"{days}일 {hours}시간 {minutes}분"
    elif hours > 0:
        return f"{hours}시간 {minutes}분"
    else:
        return f"{minutes}분 {secs % 60}초"

def resolve_safe_path(rel_path: str = "") -> str:
    """Safely resolves relative path within MEDIA_ROOT to prevent directory traversal."""
    clean_rel = rel_path.strip("/\\").replace("..", "")
    target = os.path.abspath(os.path.join(MEDIA_ROOT, clean_rel))
    if not target.startswith(os.path.abspath(MEDIA_ROOT)):
        return os.path.abspath(MEDIA_ROOT)
    return target

def format_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"

def format_relative_time(timestamp: float) -> str:
    diff = time.time() - timestamp
    if diff < 60:
        return "방금 전 🔥"
    elif diff < 3600:
        return f"{int(diff // 60)}분 전"
    elif diff < 86400:
        return f"{int(diff // 3600)}시간 전"
    elif diff < 86400 * 7:
        return f"{int(diff // 86400)}일 전"
    else:
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(timestamp))

def detect_file_type(filename: str) -> tuple[str, str]:
    ext = os.path.splitext(filename)[1].lower()
    if ext in [".mp4", ".mkv", ".webm", ".avi", ".mov", ".wmv", ".flv", ".ts", ".m4v", ".3gp"]:
        return "video", "동영상"
    elif ext in [".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac", ".wma", ".opus"]:
        return "music", "음악"
    elif ext in [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg", ".jfif", ".tif", ".tiff", ".heic", ".avif"]:
        return "photo", "사진"
    elif ext in [".zip", ".cbz", ".rar", ".7z"]:
        return "comic", "만화/압축"
    elif ext in [".txt", ".log", ".md", ".json", ".csv", ".py", ".html", ".smi", ".srt", ".vtt"]:
        return "text", "문서"
    return "other", "파일"

def generate_placeholder_svg(title: str = "", category: str = "generic") -> str:
    """Generates an ultra-fast, modern SVG placeholder thumbnail that never fails."""
    raw_title = str(title).strip() or "VibeVault"
    escaped_title = html.escape(raw_title[:28] + ("..." if len(raw_title) > 28 else ""))
    
    configs = {
        "video": {
            "grad1": "#6366f1", "grad2": "#8b5cf6",
            "icon": '<polygon points="10 8 16 12 10 16 10 8" fill="white"/>',
            "badge": "VIDEO"
        },
        "photo": {
            "grad1": "#10b981", "grad2": "#059669",
            "icon": '<rect x="3" y="3" width="18" height="18" rx="2" stroke="white" stroke-width="2" fill="none"/><circle cx="8.5" cy="8.5" r="1.5" fill="white"/><polyline points="21 15 16 10 5 21" stroke="white" stroke-width="2" fill="none"/>',
            "badge": "PHOTO"
        },
        "music": {
            "grad1": "#f43f5e", "grad2": "#be123c",
            "icon": '<path d="M9 18V5l12-2v13" stroke="white" stroke-width="2" fill="none"/><circle cx="6" cy="18" r="3" fill="white"/><circle cx="18" cy="16" r="3" fill="white"/>',
            "badge": "AUDIO"
        },
        "comic": {
            "grad1": "#f59e0b", "grad2": "#d97706",
            "icon": '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" stroke="white" stroke-width="2" fill="none"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" stroke="white" stroke-width="2" fill="none"/>',
            "badge": "COMIC"
        },
        "folder": {
            "grad1": "#3b82f6", "grad2": "#1d4ed8",
            "icon": '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" stroke="white" stroke-width="2" fill="none"/>',
            "badge": "FOLDER"
        },
        "generic": {
            "grad1": "#64748b", "grad2": "#475569",
            "icon": '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" stroke="white" stroke-width="2" fill="none"/><polyline points="13 2 13 9 20 9" stroke="white" stroke-width="2" fill="none"/>',
            "badge": "FILE"
        }
    }
    cfg = configs.get(category, configs["generic"])
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 360" width="640" height="360">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a"/>
      <stop offset="100%" stop-color="#1e1b4b"/>
    </linearGradient>
    <linearGradient id="iconGrad_{category}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{cfg['grad1']}"/>
      <stop offset="100%" stop-color="{cfg['grad2']}"/>
    </linearGradient>
    <filter id="cardGlow_{category}" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-color="{cfg['grad1']}" flood-opacity="0.35"/>
    </filter>
  </defs>
  <rect width="640" height="360" fill="url(#bgGrad)"/>
  <circle cx="320" cy="140" r="46" fill="url(#iconGrad_{category})" filter="url(#cardGlow_{category})"/>
  <g transform="translate(308, 128) scale(1)">
    {cfg['icon']}
  </g>
  <rect x="270" y="206" width="100" height="22" rx="11" fill="url(#iconGrad_{category})" opacity="0.9"/>
  <text x="320" y="221" font-family="system-ui, -apple-system, sans-serif" font-size="10" font-weight="800" fill="#ffffff" text-anchor="middle" letter-spacing="1.5">{cfg['badge']}</text>
  <text x="320" y="270" font-family="system-ui, -apple-system, sans-serif" font-size="14" font-weight="600" fill="#f8fafc" text-anchor="middle">{escaped_title}</text>
</svg>"""

def get_placeholder_svg_response(title: str = "", category: str = "generic"):
    """Returns a Response object containing the SVG placeholder with proper caching headers."""
    svg_data = generate_placeholder_svg(title, category)
    return Response(
        content=svg_data,
        media_type="image/svg+xml",
        headers={"Cache-Control": "public, max-age=86400"}
    )

def get_folder_details(folder_abs_path: str, max_depth: int = 1) -> dict:
    """Calculates file count, total size, latest content modification time, and previews."""
    item_count = 0
    total_size = 0
    latest_mtime = 0.0
    preview_items = []
    has_media_type = {"video": 0, "music": 0, "photo": 0, "comic": 0, "text": 0}

    try:
        folder_mtime = os.path.getmtime(folder_abs_path)
        latest_mtime = folder_mtime

        with os.scandir(folder_abs_path) as it:
            for entry in it:
                if entry.name.startswith(".") or entry.name == "바이브코딩":
                    continue
                item_count += 1
                try:
                    st = entry.stat()
                    if st.st_mtime > latest_mtime:
                        latest_mtime = st.st_mtime
                    if entry.is_file():
                        total_size += st.st_size
                        ftype, _ = detect_file_type(entry.name)
                        if ftype in has_media_type:
                            has_media_type[ftype] += 1
                        if len(preview_items) < 4:
                            preview_items.append(entry.name)
                    elif entry.is_dir() and max_depth > 0:
                        # Quick check for 1-level deep
                        try:
                            for sub in os.scandir(entry.path):
                                if len(preview_items) < 4:
                                    preview_items.append(sub.name)
                                sub_st = sub.stat()
                                if sub_st.st_mtime > latest_mtime:
                                    latest_mtime = sub_st.st_mtime
                        except Exception:
                            pass
                except Exception:
                    pass
    except Exception:
        pass

    # Infer primary folder category
    primary_type = "generic"
    if has_media_type["video"] > 0 and has_media_type["video"] >= max(has_media_type["music"], has_media_type["photo"]):
        primary_type = "video"
    elif has_media_type["music"] > 0:
        primary_type = "music"
    elif has_media_type["comic"] > 0:
        primary_type = "comic"
    elif has_media_type["photo"] > 0:
        primary_type = "photo"

    type_labels = {
        "video": "동영상 재생목록",
        "music": "음악 앨범/재생목록",
        "photo": "사진 갤러리",
        "comic": "만화 서재",
        "generic": "폴더"
    }

    return {
        "item_count": item_count,
        "total_size": total_size,
        "total_size_formatted": format_size(total_size),
        "latest_content_mtime": latest_mtime,
        "latest_content_mtime_formatted": time.strftime("%Y-%m-%d %H:%M", time.localtime(latest_mtime)),
        "latest_added_desc": format_relative_time(latest_mtime),
        "preview_items": preview_items,
        "type": primary_type,
        "type_label": type_labels.get(primary_type, "폴더")
    }

# ----------------- API Endpoints -----------------

@app.get("/api/browse")
async def browse_directory(path: str = Query("", description="Relative path from MEDIA_ROOT"), sort: str = "content_desc"):
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or not os.path.isdir(target_abs):
        raise HTTPException(status_code=404, detail="Directory not found")

    rel_current = os.path.relpath(target_abs, MEDIA_ROOT).replace("\\", "/")
    if rel_current == ".":
        rel_current = ""

    parent_rel = None
    if rel_current:
        parent_dir = os.path.dirname(rel_current)
        parent_rel = parent_dir if parent_dir != "." else ""

    folders = []
    files = []

    # Read custom covers map
    custom_covers = {}
    try:
        if os.path.exists(COVERS_FILE):
            with open(COVERS_FILE, "r", encoding="utf-8") as f:
                custom_covers = json.load(f)
    except Exception:
        pass

    try:
        with os.scandir(target_abs) as entries:
            for entry in entries:
                if entry.name.startswith(".") or entry.name in ["$RECYCLE.BIN", "System Volume Information", "바이브코딩"]:
                    continue

                item_rel = os.path.relpath(entry.path, MEDIA_ROOT).replace("\\", "/")
                
                if entry.is_dir():
                    details = get_folder_details(entry.path)
                    cover_url = custom_covers.get(item_rel, f"/api/thumbnail?path={item_rel}")
                    folders.append({
                        "id": hashlib.md5(item_rel.encode("utf-8")).hexdigest()[:12],
                        "name": entry.name,
                        "rel_path": item_rel,
                        "abs_path": entry.path,
                        "cover_url": cover_url,
                        **details
                    })
                elif entry.is_file():
                    st = entry.stat()
                    ftype, ftype_label = detect_file_type(entry.name)
                    ext = os.path.splitext(entry.name)[1].lower()
                    files.append({
                        "id": hashlib.md5(item_rel.encode("utf-8")).hexdigest()[:12],
                        "name": entry.name,
                        "rel_path": item_rel,
                        "abs_path": entry.path,
                        "size": st.st_size,
                        "size_formatted": format_size(st.st_size),
                        "mtime": st.st_mtime,
                        "mtime_formatted": time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
                        "ext": ext,
                        "type": ftype,
                        "type_label": ftype_label,
                        "thumbnail_url": f"/api/thumbnail?path={item_rel}" if ftype in ["video", "photo", "music", "comic"] else None
                    })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # Apply Sorting
    if sort == "content_desc":
        folders.sort(key=lambda x: x["latest_content_mtime"], reverse=True)
    elif sort == "name_asc":
        folders.sort(key=lambda x: x["name"].lower())
    elif sort == "date_desc":
        folders.sort(key=lambda x: x["latest_content_mtime"], reverse=True)
    elif sort == "size_desc":
        folders.sort(key=lambda x: x["total_size"], reverse=True)

    files.sort(key=lambda x: x["name"].lower())

    return {
        "media_root": MEDIA_ROOT,
        "current_path": rel_current,
        "parent_path": parent_rel,
        "current_name": os.path.basename(target_abs) or "외장하드 루트",
        "folders": folders,
        "files": files,
        "total_folders": len(folders),
        "total_files": len(files)
    }

@app.get("/api/thumbnail")
async def get_thumbnail(path: str = Query("", description="Relative path of file or folder")):
    # 0. Check custom covers first
    clean_path = path.strip("/\\").replace("\\", "/")
    if os.path.exists(COVERS_FILE):
        try:
            with open(COVERS_FILE, "r", encoding="utf-8") as f:
                custom_covers = json.load(f)
            if clean_path in custom_covers:
                cover_val = custom_covers[clean_path]
                if cover_val.startswith("/api/cover-image/"):
                    filename = os.path.basename(cover_val)
                    saved_path = os.path.join(COVERS_DIR, filename)
                    if os.path.exists(saved_path):
                        mime_type, _ = mimetypes.guess_type(saved_path)
                        return FileResponse(saved_path, media_type=mime_type or "image/jpeg", headers={"Cache-Control": "public, max-age=86400"})
                elif cover_val.startswith("http://") or cover_val.startswith("https://"):
                    return RedirectResponse(url=cover_val)
                elif cover_val.startswith("/api/photo") or cover_val.startswith("/api/thumbnail") or cover_val.startswith("/api/file"):
                    parsed = urllib.parse.urlparse(cover_val)
                    q_params = urllib.parse.parse_qs(parsed.query)
                    if "path" in q_params and q_params["path"][0] != path:
                        return await get_thumbnail(path=q_params["path"][0])
        except Exception:
            pass

    target_abs = resolve_safe_path(path)
    base_name = os.path.basename(target_abs) or "미디어 루트"

    # If file/dir doesn't exist on disk, return aesthetic category placeholder instead of 404
    if not os.path.exists(target_abs):
        cat = "folder" if not os.path.splitext(target_abs)[1] else detect_file_type(target_abs)[0]
        return get_placeholder_svg_response(base_name, cat)

    try:
        mtime = os.path.getmtime(target_abs)
    except Exception:
        mtime = 0.0

    cache_key = hashlib.md5(f"{target_abs}_{mtime}".encode("utf-8")).hexdigest()
    cache_file = os.path.join(CACHE_DIR, f"{cache_key}.webp")

    if os.path.exists(cache_file):
        return FileResponse(cache_file, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})

    # Determine type
    is_dir = os.path.isdir(target_abs)
    ftype, _ = ("folder", "폴더") if is_dir else detect_file_type(target_abs)

    try:
        # 1. Directory Thumbnail Search
        if is_dir:
            found_item = None
            found_type = None

            # Safe shallow scan (depth <= 2) avoiding system dirs
            target_depth = target_abs.rstrip("\\/").count(os.sep)
            try:
                for root, dirs, f_names in os.walk(target_abs):
                    # Exclude system folders and private folders to avoid permission errors
                    dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['$RECYCLE.BIN', 'System Volume Information', '바이브코딩', '.cache']]
                    current_depth = root.rstrip("\\/").count(os.sep)
                    if current_depth - target_depth > 2:
                        dirs.clear() # don't go deeper
                        continue

                    # Search for images first
                    for fn in f_names:
                        ext = os.path.splitext(fn)[1].lower()
                        if ext in [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".jfif", ".gif"]:
                            found_item = os.path.join(root, fn)
                            found_type = "photo"
                            break
                    if found_item:
                        break

                    # Then search for video files
                    if not found_item:
                        for fn in f_names:
                            ext = os.path.splitext(fn)[1].lower()
                            if ext in [".mp4", ".mkv", ".webm", ".avi", ".mov", ".wmv", ".flv", ".ts", ".m4v"]:
                                found_item = os.path.join(root, fn)
                                found_type = "video"
                                break
                    if found_item:
                        break

                    # Then search for comic / zip archives
                    if not found_item:
                        for fn in f_names:
                            ext = os.path.splitext(fn)[1].lower()
                            if ext in [".zip", ".cbz"]:
                                found_item = os.path.join(root, fn)
                                found_type = "comic"
                                break
                    if found_item:
                        break

                    # Then search for audio files
                    if not found_item:
                        for fn in f_names:
                            ext = os.path.splitext(fn)[1].lower()
                            if ext in [".mp3", ".flac", ".m4a", ".ogg", ".wav"]:
                                found_item = os.path.join(root, fn)
                                found_type = "music"
                                break
                    if found_item:
                        break
            except Exception:
                pass

            if not found_item:
                # Generate aesthetic gradient card for folder
                try:
                    import PIL.ImageDraw
                    im = PIL.Image.new("RGB", (640, 360), (16, 22, 36))
                    draw = PIL.ImageDraw.Draw(im)
                    for i in range(180):
                        c = (16 + int(i * 0.12), 22 + int(i * 0.04), 36 + int(i * 0.18))
                        draw.rectangle([(0, i * 2), (640, (i + 1) * 2)], fill=c)
                    draw.rectangle([(0, 350), (640, 360)], fill=(225, 29, 72))
                    im.save(cache_file, "WEBP", quality=85)
                    return FileResponse(cache_file, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})
                except Exception:
                    return get_placeholder_svg_response(base_name, "folder")

            # Use the found item to generate the folder's thumbnail
            target_abs = found_item
            ftype = found_type

        # Now process individual media file
        ext = os.path.splitext(target_abs)[1].lower()

        # 2. Image Files (jpg, png, webp, bmp, gif, jfif, etc.)
        if ext in [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".jfif", ".gif"]:
            try:
                with PIL.Image.open(target_abs) as im:
                    im = PIL.ImageOps.exif_transpose(im)
                    if im.mode in ("RGBA", "LA", "P"):
                        im = im.convert("RGBA")
                        bg = PIL.Image.new("RGB", im.size, (15, 23, 42))
                        bg.paste(im, mask=im.split()[3])
                        im = bg
                    else:
                        im = im.convert("RGB")
                    im.thumbnail((500, 500), PIL.Image.Resampling.LANCZOS)
                    im.save(cache_file, "WEBP", quality=85)
                return FileResponse(cache_file, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})
            except Exception:
                return get_placeholder_svg_response(os.path.basename(target_abs), "photo")

        # 3. Video Files (OpenCV Frame Extraction)
        elif ext in [".mp4", ".mkv", ".webm", ".avi", ".mov", ".wmv", ".flv", ".ts", ".m4v"]:
            frame_captured = False
            try:
                cap = cv2.VideoCapture(target_abs)
                total_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
                fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
                target_frame = min(int(fps * 5), max(0, int(total_frames * 0.1)))
                cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
                ret, frame = cap.read()
                if not ret:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ret, frame = cap.read()
                cap.release()

                if ret and frame is not None:
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    im = PIL.Image.fromarray(frame_rgb)
                    im.thumbnail((500, 500), PIL.Image.Resampling.LANCZOS)
                    im.save(cache_file, "WEBP", quality=82)
                    frame_captured = True
                    return FileResponse(cache_file, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})
            except Exception:
                pass

            if not frame_captured:
                return get_placeholder_svg_response(os.path.basename(target_abs), "video")

        # 4. ZIP Archives (First Image Inside)
        elif ext in [".zip", ".cbz"]:
            try:
                with zipfile.ZipFile(target_abs, "r") as z:
                    img_entry = None
                    for n in z.namelist():
                        if os.path.splitext(n)[1].lower() in [".jpg", ".jpeg", ".png", ".webp", ".bmp"]:
                            img_entry = n
                            break
                    if img_entry:
                        data = z.read(img_entry)
                        with PIL.Image.open(io.BytesIO(data)) as im:
                            im = PIL.ImageOps.exif_transpose(im)
                            im = im.convert("RGB")
                            im.thumbnail((500, 500), PIL.Image.Resampling.LANCZOS)
                            im.save(cache_file, "WEBP", quality=82)
                        return FileResponse(cache_file, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})
            except Exception:
                pass
            return get_placeholder_svg_response(os.path.basename(target_abs), "comic")

        # 5. Audio Files (Mutagen Album Art Extraction)
        elif ext in [".mp3", ".flac", ".m4a", ".ogg", ".wav"]:
            try:
                mf = mutagen.File(target_abs)
                if mf:
                    art_data = None
                    # ID3 (MP3)
                    if hasattr(mf, "tags") and mf.tags:
                        for key in mf.tags.keys():
                            if key.startswith("APIC"):
                                art_data = mf.tags[key].data
                                break
                    # FLAC
                    if not art_data and hasattr(mf, "pictures") and mf.pictures:
                        art_data = mf.pictures[0].data

                    if art_data:
                        with PIL.Image.open(io.BytesIO(art_data)) as im:
                            im = PIL.ImageOps.exif_transpose(im)
                            im = im.convert("RGB")
                            im.thumbnail((500, 500), PIL.Image.Resampling.LANCZOS)
                            im.save(cache_file, "WEBP", quality=85)
                        return FileResponse(cache_file, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})
            except Exception:
                pass
            return get_placeholder_svg_response(os.path.basename(target_abs), "music")

    except Exception:
        pass

    # Never return 404! Always return a beautiful, reliable fallback response with 200 OK!
    cat = ftype if ftype in ["video", "photo", "music", "comic", "folder"] else "generic"
    return get_placeholder_svg_response(base_name, cat)

@app.get("/api/cover-image/{filename}")
async def get_cover_image(filename: str):
    """Serves custom uploaded cover images."""
    clean_name = os.path.basename(filename)
    saved_path = os.path.join(COVERS_DIR, clean_name)
    if os.path.exists(saved_path):
        mime_type, _ = mimetypes.guess_type(saved_path)
        return FileResponse(saved_path, media_type=mime_type or "image/jpeg", headers={"Cache-Control": "public, max-age=86400"})
    return get_placeholder_svg_response(clean_name, "photo")

@app.get("/api/photo")
async def get_photo(path: str = Query(..., description="Relative path of photo")):
    """Serves high-quality photo for the photo viewer with inline display."""
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or os.path.isdir(target_abs):
        return get_placeholder_svg_response(os.path.basename(path), "photo")
    
    mime_type, _ = mimetypes.guess_type(target_abs)
    if not mime_type or not mime_type.startswith("image/"):
        ext = os.path.splitext(target_abs)[1].lower()
        mime_map = {
            ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
            ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp",
            ".jfif": "image/jpeg", ".svg": "image/svg+xml"
        }
        mime_type = mime_map.get(ext, "image/jpeg")

    return FileResponse(
        target_abs, 
        media_type=mime_type, 
        headers={
            "Content-Disposition": f"inline; filename*=UTF-8''{urllib.parse.quote(os.path.basename(target_abs))}",
            "Cache-Control": "public, max-age=3600"
        }
    )

@app.get("/api/raw-image")
async def get_raw_image(path: str = Query(...)):
    """Alias for /api/photo for maximum compatibility."""
    return await get_photo(path=path)

@app.get("/api/photo-info")
async def get_photo_info(path: str = Query(...)):
    """Returns photo metadata, dimensions, and size for photo viewer display."""
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or os.path.isdir(target_abs):
        raise HTTPException(status_code=404, detail="Photo not found")
    
    st = os.stat(target_abs)
    width, height = 0, 0
    try:
        with PIL.Image.open(target_abs) as im:
            width, height = im.size
    except Exception:
        pass
    
    return {
        "filename": os.path.basename(target_abs),
        "rel_path": path,
        "size": st.st_size,
        "size_formatted": format_size(st.st_size),
        "mtime": st.st_mtime,
        "mtime_formatted": time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
        "width": width,
        "height": height,
        "dimensions": f"{width} × {height} px" if width and height else "알 수 없음"
    }

@app.get("/api/stream")
async def stream_media(path: str = Query(..., description="Relative path of media file")):
    """Streams video/audio supporting HTTP 206 Partial Content (Range requests for seeking)."""
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or os.path.isdir(target_abs):
        raise HTTPException(status_code=404, detail="Media file not found")

    mime_type, _ = mimetypes.guess_type(target_abs)
    if not mime_type:
        ext = os.path.splitext(target_abs)[1].lower()
        mime_map = {
            ".mp4": "video/mp4",
            ".mkv": "video/x-matroska",
            ".webm": "video/webm",
            ".mp3": "audio/mpeg",
            ".wav": "audio/wav",
            ".flac": "audio/flac",
            ".m4a": "audio/mp4",
            ".ogg": "audio/ogg"
        }
        mime_type = mime_map.get(ext, "application/octet-stream")

    return FileResponse(target_abs, media_type=mime_type, filename=os.path.basename(target_abs))

@app.get("/api/file")
async def get_raw_file(path: str = Query(...)):
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or os.path.isdir(target_abs):
        raise HTTPException(status_code=404, detail="File not found")
    mime_type, _ = mimetypes.guess_type(target_abs)
    return FileResponse(target_abs, media_type=mime_type or "application/octet-stream", filename=os.path.basename(target_abs))

@app.get("/api/text")
async def read_text_file(path: str = Query(...)):
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or os.path.isdir(target_abs):
        raise HTTPException(status_code=404, detail="Text file not found")

    try:
        with open(target_abs, "rb") as f:
            raw = f.read(1024 * 512) # Read first 512KB for encoding detection and preview
            detected = chardet.detect(raw)
            encoding = detected.get("encoding") or "utf-8"

        # Read full text with detected encoding
        with open(target_abs, "r", encoding=encoding, errors="replace") as f:
            content = f.read(1024 * 256) # Read up to 256KB for viewer display

        st = os.stat(target_abs)
        return {
            "title": os.path.basename(target_abs),
            "encoding": f"{encoding.upper()} (자동 감지)",
            "stats": f"{len(content):,} 자 • {format_size(st.st_size)}",
            "content": content
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Text read error: {str(e)}")

@app.get("/api/zip-pages")
async def get_zip_pages(path: str = Query(...)):
    """Lists all image entries in a ZIP archive for the manga/comic viewer in natural order."""
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="ZIP archive not found")

    def natural_sort_key(s):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]

    try:
        with zipfile.ZipFile(target_abs, "r") as z:
            pages = []
            for name in z.namelist():
                ext = os.path.splitext(name)[1].lower()
                if ext in [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"] and not name.startswith("__MACOSX"):
                    pages.append(name)
            pages.sort(key=natural_sort_key)
            return {
                "title": os.path.basename(target_abs),
                "total_pages": len(pages),
                "pages": pages
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"ZIP read error: {str(e)}")

@app.get("/api/zip-page")
async def get_zip_page(path: str = Query(...), page: str = Query(...)):
    """Extracts and streams a single image directly from a ZIP file in-memory."""
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="ZIP not found")

    try:
        with zipfile.ZipFile(target_abs, "r") as z:
            data = z.read(page)
            mime_type, _ = mimetypes.guess_type(page)
            return Response(content=data, media_type=mime_type or "image/jpeg", headers={"Cache-Control": "public, max-age=3600"})
    except Exception as e:
        raise HTTPException(status_code=404, detail="Page not found in archive")

@app.post("/api/upload")
async def upload_file(
    target_path: str = Form(""),
    file: UploadFile = File(...)
):
    """Real file upload endpoint. Saves chunks to disk asynchronously with zero memory bloat."""
    target_abs = resolve_safe_path(target_path)
    if not os.path.exists(target_abs):
        os.makedirs(target_abs, exist_ok=True)

    dest_file = os.path.join(target_abs, file.filename)
    total_written = 0

    try:
        async with aiofiles.open(dest_file, "wb") as out_file:
            while chunk := await file.read(1024 * 1024): # 1MB chunk
                await out_file.write(chunk)
                total_written += len(chunk)
        
        # Touch folder mtime so latest content order updates immediately
        os.utime(target_abs, None)

        rel_dest = os.path.relpath(dest_file, MEDIA_ROOT).replace("\\", "/")
        return {
            "success": True,
            "filename": file.filename,
            "rel_path": rel_dest,
            "size": total_written,
            "size_formatted": format_size(total_written),
            "message": f"'{file.filename}' 파일이 성공적으로 외장하드에 업로드되었습니다!"
        }
    except Exception as e:
        if os.path.exists(dest_file):
            try:
                os.remove(dest_file)
            except Exception:
                pass
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@app.post("/api/create-folder")
async def create_folder(parent_path: str = Form(""), folder_name: str = Form(...)):
    clean_name = folder_name.strip().replace("/", "").replace("\\", "")
    if not clean_name:
        raise HTTPException(status_code=400, detail="Folder name is required")
    target_dir = resolve_safe_path(os.path.join(parent_path, clean_name))
    try:
        os.makedirs(target_dir, exist_ok=True)
        return {"success": True, "folder_name": clean_name, "rel_path": os.path.relpath(target_dir, MEDIA_ROOT).replace("\\", "/")}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/virtual-libraries")
async def get_virtual_libraries():
    libs = []
    try:
        if os.path.exists(LIBRARIES_FILE):
            with open(LIBRARIES_FILE, "r", encoding="utf-8") as f:
                libs = json.load(f)
    except Exception:
        return []

    custom_covers = {}
    try:
        if os.path.exists(COVERS_FILE):
            with open(COVERS_FILE, "r", encoding="utf-8") as f:
                custom_covers = json.load(f)
    except Exception:
        pass

    # Enrich each folder in each library with real details and covers
    for lib in libs:
        folders_enriched = []
        for folder_entry in lib.get("folders", []):
            f_path = folder_entry.get("path", "")
            clean_rel = f_path.strip("/\\").replace("\\", "/")
            f_abs = resolve_safe_path(clean_rel)
            
            cover_url = custom_covers.get(clean_rel, f"/api/thumbnail?path={clean_rel}")
            details = get_folder_details(f_abs) if os.path.exists(f_abs) and os.path.isdir(f_abs) else {}

            folders_enriched.append({
                **folder_entry,
                "abs_path": f_abs,
                "cover_url": cover_url,
                "item_count": details.get("item_count", 0),
                "total_size": details.get("total_size", 0),
                "total_size_formatted": details.get("total_size_formatted", "0 B"),
                "latest_content_mtime": details.get("latest_content_mtime", 0.0),
                "latest_added_desc": details.get("latest_added_desc", "최근"),
                "type": details.get("type", "generic"),
                "type_label": details.get("type_label", "폴더"),
            })
        lib["folders"] = folders_enriched
        if not lib.get("coverUrl") and folders_enriched:
            lib["coverUrl"] = folders_enriched[0]["cover_url"]

    return libs

@app.post("/api/virtual-libraries")
async def save_virtual_libraries(libs: List[Dict[str, Any]]):
    try:
        # Strip transient enriched fields before saving to keep libraries.json clean
        clean_libs = []
        for l in libs:
            clean_folders = []
            for f in l.get("folders", []):
                clean_folders.append({
                    "path": f.get("path", ""),
                    "name": f.get("name", ""),
                    "added_at": f.get("added_at", time.strftime("%Y-%m-%dT%H:%M:%S"))
                })
            clean_libs.append({
                "id": l.get("id"),
                "title": l.get("title"),
                "desc": l.get("desc", ""),
                "coverUrl": l.get("coverUrl", ""),
                "folders": clean_folders
            })
        with open(LIBRARIES_FILE, "w", encoding="utf-8") as f:
            json.dump(clean_libs, f, ensure_ascii=False, indent=2)
        return {"success": True, "count": len(clean_libs)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/set-cover")
async def set_folder_cover(folder_path: str = Form(...), cover_url: str = Form(...)):
    try:
        covers = {}
        if os.path.exists(COVERS_FILE):
            with open(COVERS_FILE, "r", encoding="utf-8") as f:
                covers = json.load(f)
        clean_path = folder_path.strip("/\\").replace("\\", "/")
        covers[clean_path] = cover_url
        with open(COVERS_FILE, "w", encoding="utf-8") as f:
            json.dump(covers, f, ensure_ascii=False, indent=2)
        return {"success": True, "folder_path": clean_path, "cover_url": cover_url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/upload-cover")
async def upload_cover(folder_path: str = Form(...), file: UploadFile = File(...)):
    """Allows uploading a custom image file to serve as folder/library cover."""
    clean_path = folder_path.strip("/\\").replace("\\", "/")
    covers_dir = os.path.join(WORKSPACE_DIR, ".cache", "covers")
    os.makedirs(covers_dir, exist_ok=True)

    file_ext = os.path.splitext(file.filename)[1].lower() or ".jpg"
    hash_name = hashlib.md5(f"{clean_path}_{time.time()}".encode("utf-8")).hexdigest()[:16]
    saved_filename = f"{hash_name}{file_ext}"
    saved_path = os.path.join(covers_dir, saved_filename)

    content = await file.read()
    with open(saved_path, "wb") as f:
        f.write(content)

    cover_url = f"/api/cover-image/{saved_filename}"

    covers = {}
    if os.path.exists(COVERS_FILE):
        try:
            with open(COVERS_FILE, "r", encoding="utf-8") as f:
                covers = json.load(f)
        except Exception:
            pass
    covers[clean_path] = cover_url
    with open(COVERS_FILE, "w", encoding="utf-8") as f:
        json.dump(covers, f, ensure_ascii=False, indent=2)

    return {"success": True, "folder_path": clean_path, "cover_url": cover_url}

@app.post("/api/remove-cover")
async def remove_folder_cover(folder_path: str = Form(...)):
    """Removes custom cover and falls back to auto-generated thumbnail."""
    try:
        clean_path = folder_path.strip("/\\").replace("\\", "/")
        covers = {}
        if os.path.exists(COVERS_FILE):
            with open(COVERS_FILE, "r", encoding="utf-8") as f:
                covers = json.load(f)
        if clean_path in covers:
            del covers[clean_path]
            with open(COVERS_FILE, "w", encoding="utf-8") as f:
                json.dump(covers, f, ensure_ascii=False, indent=2)
        return {"success": True, "folder_path": clean_path, "message": "커버가 기본값으로 초기화되었습니다."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/set-library-cover")
async def set_library_cover(lib_id: str = Form(...), cover_url: str = Form(...)):
    """Sets a custom cover image URL for a virtual library hero card."""
    try:
        libs = []
        if os.path.exists(LIBRARIES_FILE):
            with open(LIBRARIES_FILE, "r", encoding="utf-8") as f:
                libs = json.load(f)
        found = False
        for l in libs:
            if l.get("id") == lib_id:
                l["coverUrl"] = cover_url
                found = True
                break
        if not found:
            raise HTTPException(status_code=404, detail="Library not found")
        with open(LIBRARIES_FILE, "w", encoding="utf-8") as f:
            json.dump(libs, f, ensure_ascii=False, indent=2)
        return {"success": True, "lib_id": lib_id, "cover_url": cover_url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/upload-library-cover")
async def upload_library_cover(lib_id: str = Form(...), file: UploadFile = File(...)):
    """Uploads a dedicated cover image for a virtual library."""
    covers_dir = os.path.join(WORKSPACE_DIR, ".cache", "covers")
    os.makedirs(covers_dir, exist_ok=True)

    file_ext = os.path.splitext(file.filename)[1].lower() or ".jpg"
    hash_name = hashlib.md5(f"lib_{lib_id}_{time.time()}".encode("utf-8")).hexdigest()[:16]
    saved_filename = f"{hash_name}{file_ext}"
    saved_path = os.path.join(covers_dir, saved_filename)

    content = await file.read()
    with open(saved_path, "wb") as f:
        f.write(content)

    cover_url = f"/api/cover-image/{saved_filename}"

    libs = []
    if os.path.exists(LIBRARIES_FILE):
        with open(LIBRARIES_FILE, "r", encoding="utf-8") as f:
            libs = json.load(f)
    for l in libs:
        if l.get("id") == lib_id:
            l["coverUrl"] = cover_url
            break
    with open(LIBRARIES_FILE, "w", encoding="utf-8") as f:
        json.dump(libs, f, ensure_ascii=False, indent=2)

    return {"success": True, "lib_id": lib_id, "cover_url": cover_url}

@app.get("/api/folder-images")
async def get_folder_images(path: str = Query("", description="Folder relative path")):
    """Returns list of image files inside a folder for convenient cover selection."""
    target_abs = resolve_safe_path(path)
    if not os.path.exists(target_abs) or not os.path.isdir(target_abs):
        raise HTTPException(status_code=404, detail="Directory not found")

    images = []
    try:
        with os.scandir(target_abs) as entries:
            for entry in entries:
                if entry.is_file():
                    ext = os.path.splitext(entry.name)[1].lower()
                    if ext in [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"]:
                        rel_file = os.path.relpath(entry.path, MEDIA_ROOT).replace("\\", "/")
                        st = entry.stat()
                        images.append({
                            "name": entry.name,
                            "rel_path": rel_file,
                            "thumbnail_url": f"/api/thumbnail?path={rel_file}",
                            "size_formatted": format_size(st.st_size),
                            "mtime": st.st_mtime
                        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    images.sort(key=lambda x: x["name"].lower())
    return {"folder_path": path, "total": len(images), "images": images}

@app.get("/api/config")
async def get_system_config():
    """Returns current media root, detection candidates, and drive info."""
    candidates = find_media_root_candidates()
    return {
        "media_root": MEDIA_ROOT,
        "is_valid": os.path.exists(MEDIA_ROOT) and os.path.isdir(MEDIA_ROOT),
        "candidates": candidates,
        "parent_dir": PARENT_DIR,
        "workspace_dir": WORKSPACE_DIR
    }

@app.post("/api/config")
async def update_system_config(media_root: str = Form(...)):
    """Allows setting custom external hard drive media root path via web UI."""
    global MEDIA_ROOT
    clean_path = os.path.abspath(media_root.strip().strip('"').strip("'"))
    if not os.path.exists(clean_path) or not os.path.isdir(clean_path):
        raise HTTPException(status_code=400, detail=f"지정한 외장하드/폴더 경로를 찾을 수 없습니다: {clean_path}")

    MEDIA_ROOT = clean_path
    cfg = load_config()
    cfg["media_root"] = clean_path
    save_config(cfg)

    return {
        "success": True,
        "media_root": MEDIA_ROOT,
        "message": f"외장하드 미디어 루트가 '{clean_path}'(으)로 정상 변경되었습니다."
    }

@app.get("/api/server-info")
async def get_server_info():
    """Returns 24H server hosting info, LAN & Tailscale IPs for QR code / phone connection, and disk storage stats."""
    lan_ips = get_lan_ips()
    port = 8000

    tailscale_ip = None
    lan_ip = None
    for ip in lan_ips:
        if is_tailscale_ip(ip):
            if not tailscale_ip:
                tailscale_ip = ip
        elif not lan_ip and not ip.startswith("127."):
            lan_ip = ip

    primary_ip = tailscale_ip or lan_ip or (lan_ips[0] if lan_ips else "127.0.0.1")

    # Calculate disk usage for MEDIA_ROOT
    disk_info = {"total": 0, "free": 0, "used": 0, "percent_free": 0, "total_formatted": "0 GB", "free_formatted": "0 GB"}
    try:
        total, used, free = shutil.disk_usage(MEDIA_ROOT)
        disk_info = {
            "total": total,
            "free": free,
            "used": used,
            "percent_free": round((free / total) * 100, 1) if total > 0 else 0,
            "total_formatted": format_size(total),
            "free_formatted": format_size(free),
            "used_formatted": format_size(used)
        }
    except Exception:
        pass

    uptime_secs = time.time() - SERVER_START_TIME

    return {
        "status": "online",
        "title": "VibeVault 24H Home Server",
        "port": port,
        "local_url": f"http://localhost:{port}",
        "primary_url": f"http://{primary_ip}:{port}",
        "primary_ip": primary_ip,
        "tailscale_ip": tailscale_ip,
        "tailscale_url": f"http://{tailscale_ip}:{port}" if tailscale_ip else None,
        "is_tailscale_active": bool(tailscale_ip),
        "lan_ip": lan_ip or (lan_ips[0] if lan_ips else "127.0.0.1"),
        "lan_url": f"http://{lan_ip or (lan_ips[0] if lan_ips else '127.0.0.1')}:{port}",
        "lan_ips": lan_ips,
        "media_root": MEDIA_ROOT,
        "disk": disk_info,
        "uptime_seconds": int(uptime_secs),
        "uptime_formatted": format_uptime(uptime_secs),
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(SERVER_START_TIME)),
        "firewall_status": "inbound_port_8000_allowed",
        "tunneling_guide": {
            "cloudflare": f"cloudflared tunnel --url http://localhost:{port}",
            "localtunnel": f"npx localtunnel --port {port}",
            "ngrok": f"ngrok http {port}"
        }
    }

# ----------------- Favicon Endpoints -----------------

@app.get("/favicon.svg")
async def get_favicon_svg():
    return Response(content=FAVICON_SVG, media_type="image/svg+xml", headers={"Cache-Control": "public, max-age=86400"})

@app.get("/favicon.ico")
async def get_favicon_ico():
    return Response(content=FAVICON_SVG, media_type="image/svg+xml", headers={"Cache-Control": "public, max-age=86400"})

# ----------------- Serve Web Frontend -----------------

@app.get("/", response_class=HTMLResponse)
async def serve_index():
    index_path = os.path.join(WORKSPACE_DIR, "index.html")
    if not os.path.exists(index_path):
        # Fallback to preview.html if index.html is being prepared
        index_path = os.path.join(WORKSPACE_DIR, "preview.html")
    with open(index_path, "r", encoding="utf-8") as f:
        return f.read()

if __name__ == "__main__":
    import uvicorn
    lan_ips = get_lan_ips()
    tailscale_ip = next((ip for ip in lan_ips if is_tailscale_ip(ip)), None)
    lan_ip = next((ip for ip in lan_ips if not is_tailscale_ip(ip) and not ip.startswith("127.")), None)

    print("=" * 64)
    print("  🚀 VibeVault 24H 파일 & 미디어 홈서버 (Master Final)")
    print("=" * 64)
    print(f"📂 외장하드 미디어 루트: {MEDIA_ROOT}")
    print(f"💻 PC 로컬 접속:         http://localhost:8000")
    if tailscale_ip:
        print(f"🌐 테일스케일(Tailscale): http://{tailscale_ip}:8000 (모바일 연결 최우선 추천 ⭐)")
    if lan_ip:
        print(f"📱 로컬 Wi-Fi (LAN):      http://{lan_ip}:8000 (동일 와이파이 연결 시)")
    print(f"🛡️ 윈도우 방화벽:         인바운드 8000번 포트 정상 허용 확인됨")
    print("=" * 64)
    print("💡 스마트폰 Tailscale 앱을 켠 상태에서 위 테일스케일 주소로 접속하세요!")
    print("=" * 64)

    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=False)
