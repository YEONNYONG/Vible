@echo off
cd /d "%~dp0"
title VibeVault Package Installer

echo ===================================================================
echo     VibeVault Python Package Installer
echo ===================================================================
echo.
python -m pip install -r requirements.txt
echo.
echo ===================================================================
echo     Installation finished! You can now run run.bat
echo ===================================================================
echo.
pause
