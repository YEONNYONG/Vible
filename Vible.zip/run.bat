@echo off
cd /d "%~dp0"
title VibeVault 24H Home Server

echo ===================================================================
echo     VibeVault 24H File and Media Home Server (Master Final)
echo ===================================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH!
    echo.
    echo 1. Download and install Python from: https://www.python.org/downloads/
    echo 2. Check the box [Add python.exe to PATH] on the first installation screen!
    echo.
    pause
    exit /b 1
)

echo [1/2] Opening Web Browser (http://localhost:8000)...
start http://localhost:8000
echo.

echo [2/2] Starting Python FastAPI Server...
echo (Press Ctrl+C in this window to stop the server)
echo.

python server.py
if errorlevel 1 (
    echo.
    echo [ERROR] Server terminated with an error.
    pause
)
